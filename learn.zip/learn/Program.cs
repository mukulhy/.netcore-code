

using learn.identity_server;
using learn.model;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.EntityFrameworkCore;

using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;

var builder = WebApplication.CreateBuilder(args);


    builder.Services.AddDbContext<StudentDb>(options =>
        options.UseSqlServer(builder.Configuration.GetConnectionString("learn")));

// for identity server 



builder.Services.AddIdentityServer()
            .AddDeveloperSigningCredential(filename: "tempkey.rsa")
            .AddInMemoryApiResources(Config.GetApiResources())
            .AddInMemoryIdentityResources(Config.GetIdentityResources())
            .AddInMemoryClients(Config.GetClients())
            .AddTestUsers(Config.GetUsers());

// omitted for brevity





//for authentication id_server
builder.Services.AddControllers();

JwtSecurityTokenHandler.DefaultInboundClaimTypeMap.Clear();

builder.Services.AddAuthentication(options =>
{
    options.DefaultScheme =
        CookieAuthenticationDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme =
        OpenIdConnectDefaults.AuthenticationScheme;
})
.AddCookie()
.AddOpenIdConnect(options =>
{
    options.SignInScheme = CookieAuthenticationDefaults.AuthenticationScheme;
    options.Authority = "https://localhost:7088"; // Auth Server  
    options.RequireHttpsMetadata = false; // only for development   
    options.ClientId = "fiver_auth_client"; // client setup in Auth Server  
    options.ClientSecret = "secret";
    options.ResponseType = "code id_token"; // means Hybrid flow  
    options.Scope.Add("fiver_auth_api");
    options.Scope.Add("offline_access");
    options.GetClaimsFromUserInfoEndpoint = true;
    options.SaveTokens = true;
});

builder.Services.AddMvc();





// Add services to the container.

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
//for identity server
app.UseIdentityServer();
//app.UseStaticFiles();
app.UseAuthentication();

app.UseAuthorization();
//for




app.MapControllers();

app.Run();
