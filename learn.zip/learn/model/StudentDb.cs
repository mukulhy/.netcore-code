﻿using Microsoft.EntityFrameworkCore;

namespace learn.model
{
    public class StudentDb :DbContext
    {
        public StudentDb(DbContextOptions<StudentDb> options): base(options)
        {

        }
        public DbSet<student> learn { get; set; }
    }
}
