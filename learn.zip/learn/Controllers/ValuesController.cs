﻿using learn.model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace learn.Controllers
{
 //   [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        private readonly StudentDb _db;
        public ValuesController(StudentDb db)
        {
            _db = db;
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<student>>> GetStudents()
        {
            return await _db.learn.ToListAsync();
        }
        [HttpPost]
        public async Task<IActionResult> Poststudent([FromBody] student addingstudent)
        {
            _db.Add(addingstudent);
            await _db.SaveChangesAsync();
            return CreatedAtAction("Poststudent", new { id = addingstudent.Id }, addingstudent);
        }
        [HttpGet("{id}")]
        
        public async Task<IActionResult> Getstudent(int id)
        {
            var student = await _db.learn.FindAsync(id);
            return Ok(student);
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> Putstudent( int id, student updatingstudent)
        {
            
            _db.learn.Update(updatingstudent);
            await _db.SaveChangesAsync();
            return Ok();
        }
        [HttpDelete ("{id}")]
        public async Task<IActionResult> Deletestudent(int id)
        { var deleteid = await _db.learn.FindAsync(id);   
            _db.learn.Remove(deleteid);
            await _db.SaveChangesAsync();
            return Ok();
        }
        
    }
}
