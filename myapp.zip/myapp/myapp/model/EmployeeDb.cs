﻿using Microsoft.EntityFrameworkCore;

namespace myapp.model
{
    public class EmployeeDb :DbContext
    {
        public EmployeeDb(DbContextOptions<EmployeeDb> options) : base(options)
        {

        }
        public DbSet<employee> Employees { get; set; }
    }
}
